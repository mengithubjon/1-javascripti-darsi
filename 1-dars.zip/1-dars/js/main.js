alert ('Javascript 1-dars');


console.log("     *     ");
console.log("    ***    ");
console.log("   *****   ");
console.log("  *******  ");
console.log(" ********* ");

let ism = 'Abror';

console.log(ism);

let familya = 'Turdiqulov';

console.log(familya);



let yosh = '16';

console.log(yosh);

let yashashjoyi = 'Jizzax viloyati';

console.log(yashashjoyi);